package nl.mijnreef.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 101;
    private static final int SAVE_BACKUP = 102;
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String HOME_URL = "https://" + APP_HOST + "/assets/index.html";

    private WebView webView;
    private android.webkit.ValueCallback<Uri[]> pendingFileCallback;
    private byte[] pendingBackup;
    private Uri pendingCameraUri;
    private final Handler mainThread = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6, 21, 28));
        getWindow().setNavigationBarColor(Color.rgb(6, 21, 28));
        getWindow().getDecorView().setSystemUiVisibility(0);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new ReefBridge(), "ReefBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && APP_HOST.equals(uri.getHost()) &&
                    "/assets/index.html".equals(uri.getPath())) {
                    try {
                        InputStream source = getAssets().open("index.html");
                        return new WebResourceResponse("text/html", "UTF-8", source);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                                new java.io.ByteArrayInputStream("Bestand niet gevonden".getBytes(StandardCharsets.UTF_8)));
                    }
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && APP_HOST.equals(uri.getHost()) &&
                      "/assets/index.html".equals(uri.getPath())) return false;
                if ("https".equals(uri.getScheme()) &&
                      ("chatgpt.com".equals(uri.getHost()) || "chat.openai.com".equals(uri.getHost()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException e) { showMessage("Geen browser beschikbaar"); }
                }
                // Do not load third-party pages in the WebView that has the JS bridge.
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView,
                   android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = callback;
                boolean wantsPhoto = false;
                for (String accept : params.getAcceptTypes())
                    if (accept != null && accept.contains("image")) wantsPhoto = true;
                Intent select = new Intent(Intent.ACTION_GET_CONTENT);
                select.addCategory(Intent.CATEGORY_OPENABLE);
                select.setType(wantsPhoto ? "image/*" : "application/json");
                Intent chooser = Intent.createChooser(select, wantsPhoto ? "Foto kiezen" : "Back-up kiezen");
                if (wantsPhoto) {
                    // A camera option is offered using the Android MediaStore provider.
                    Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (camera.resolveActivity(getPackageManager()) != null) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "mijn-reef-ai-" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                        if (pendingCameraUri != null) {
                            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                        }
                    }
                }
                try { startActivityForResult(chooser, PICK_FILE); }
                catch (Exception e) { pendingFileCallback = null; callback.onReceiveValue(null); showMessage("Foto's of bestanden kiezen lukt niet"); }
                return true;
            }
        });
        webView.loadUrl(HOME_URL);
    }

    private void showMessage(String text) {
        mainThread.post(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show());
    }

    private class ReefBridge {
        @JavascriptInterface public void copyText(String text) {
            mainThread.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Aquariumvraag", text));
            });
        }
        @JavascriptInterface public void saveBackup(String suggestedName, String base64) {
            mainThread.post(() -> {
                try {
                    // Local backups only. No third-party service or paid API is involved.
                    if (base64.length() > 32_000_000) { showMessage("Back-up te groot"); return; }
                    pendingBackup = Base64.decode(base64, Base64.DEFAULT);
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, suggestedName.endsWith(".json") ? suggestedName : "mijn-reef-ai-backup.json");
                    startActivityForResult(i, SAVE_BACKUP);
                } catch (Exception e) { showMessage("Back-up opslaan is niet gelukt"); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    ClipData clip = data.getClipData();
                    result = new Uri[clip.getItemCount()];
                    for (int j=0;j<clip.getItemCount();j++) result[j] = clip.getItemAt(j).getUri();
                } else if (data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                } else if (pendingCameraUri != null) {
                    result = new Uri[]{pendingCameraUri};
                }
            }
            if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(result);
            pendingFileCallback = null;
            boolean cameraUsed = resultCode == RESULT_OK && pendingCameraUri != null &&
                    (data == null || data.getData() == null);
            if (!cameraUsed && pendingCameraUri != null) {
                // Remove unused empty camera placeholder if gallery was chosen or picker canceled.
                try { getContentResolver().delete(pendingCameraUri, null, null); } catch (Exception ignored) {}
            }
            pendingCameraUri = null;
        } else if (requestCode == SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out == null) throw new IOException("Cannot open destination");
                    out.write(pendingBackup);
                    showMessage("Back-up opgeslagen");
                } catch (Exception e) { showMessage("Back-up bewaren mislukt"); }
            }
            pendingBackup = null;
        }
    }

    @Override protected void onDestroy() {
        if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
        if (webView != null) { webView.removeJavascriptInterface("ReefBridge"); webView.destroy(); }
        super.onDestroy();
    }
}
