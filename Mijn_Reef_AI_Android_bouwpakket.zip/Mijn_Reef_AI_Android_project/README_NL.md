# Mijn Reef AI – Android-project (gratis)

Dit is de echte Android-appvariant van de bestaande lokale aquariumlogboek-webversie.
De app draait offline in een eigen Android WebView, met een app-icoon en zonder browserbalk.
Er is **geen AI API-koppeling** en **geen betaalde dienst**.

## Wat werkt?
- Aquariumprofiel bijhouden
- Logboek met foto van galerij of camera
- Watermetingen bewaren
- Vragen en antwoorden in je geschiedenis bewaren
- Aquariumvraag + relevante context kopiëren en ChatGPT in een aparte app of browser openen
- Back-up naar een JSON-bestand via Android-systeembestandskiezer, en terugzetten
- Lokaal opslaan: de app hoeft niet online te zijn voor het logboek

## Een APK bouwen (gratis met Android Studio)
1. Pak de ZIP uit op een Windows-, Mac- of Linux-computer.
2. Open de **map Mijn_Reef_AI_Android_project** in Android Studio (niet alleen een bestand).
3. Laat Android Studio de Android SDK en Gradle-projectafhankelijkheden installeren of synchroniseren. Gebruik Java/JDK 17 of de door Android Studio meegeleverde JDK.
4. Kies in het menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Het bestand verschijnt in `app/build/outputs/apk/debug/app-debug.apk`.
6. Zet dit APK-bestand op je Samsung-telefoon en open het om te installeren. Android kan om toestemming vragen voor installatie uit deze bron.

**Let op:** Dit project is gemaakt, maar kon hier niet naar APK worden gecompileerd of op een Samsung-toestel getest, omdat de Android SDK/bouwtools in deze werkomgeving ontbreken. De APK bestaat dus nog niet.

## Belangrijk over het bestaande logboek
De Android-app heeft eigen lokale opslag, gescheiden van je huidige Chrome HTML-bestand.
Heb je al gegevens in Chrome ingevoerd? Open de oude HTML-versie > Mijn aquarium > **Back-up downloaden**.
Open daarna de Android-app > Mijn aquarium > **Back-up terugzetten**, en selecteer dat JSON-bestand.
Dit gaat niet automatisch. Maak regelmatig nieuwe back-ups, zeker vóór herinstallatie of het wissen van appgegevens.

## Privacy en grenzen
Foto's en logboek blijven lokaal op je apparaat tot je zelf een back-up maakt of een vraag naar ChatGPT kopieert en deelt.
Voor fotoanalyse moet je de originele foto zelf in ChatGPT toevoegen; de Android-app analyseert foto's niet zelf.
OpenAI API is niet gekoppeld, dus er zijn geen extra API-kosten. Je bestaande Plus-abonnement is niet direct 'ingebouwd' in de app.
De app bevat geen login, cloudback-up of veilige versleuteling. Androids app-sandbox schermt de appgegevens normaal af van andere apps.

## Optioneel bouwen via GitHub (zonder Android Studio)
Een GitHub Actions-workflow (`.github/workflows/bouw-apk.yml`) kan de APK automatisch bouwen
als de projectbestanden naar een GitHub-repository worden geüpload. Je hebt hiervoor
wel een GitHub-account nodig. Bij een openbaar project is de standaard GitHub Actions
gebruiksruimte normaal gesproken kosteloos; controleer de actuele voorwaarden.
Open daarna in GitHub Actions > 'Bouw gratis Android APK' > Run workflow, en download
het APK-artifact. Dit is alleen een alternatief, geen geïntegreerde functie van ChatGPT.
